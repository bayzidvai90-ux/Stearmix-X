package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.Announcement
import com.example.data.model.Category
import com.example.data.model.ContentItem
import com.example.data.model.ContentRequest
import com.example.data.model.DownloadItem
import com.example.data.model.Episode
import com.example.data.model.SavedItem
import com.example.data.model.User
import com.example.data.model.WatchHistory

@Database(
    entities = [
        User::class,
        ContentItem::class,
        Episode::class,
        Category::class,
        ContentRequest::class,
        SavedItem::class,
        WatchHistory::class,
        DownloadItem::class,
        Announcement::class
    ],
    version = 3,
    exportSchema = false
)
abstract class StreamixDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun contentDao(): ContentDao
    abstract fun episodeDao(): EpisodeDao
    abstract fun categoryDao(): CategoryDao
    abstract fun contentRequestDao(): ContentRequestDao
    abstract fun savedItemDao(): SavedItemDao
    abstract fun watchHistoryDao(): WatchHistoryDao
    abstract fun downloadDao(): DownloadDao
    abstract fun announcementDao(): AnnouncementDao

    companion object {
        @Volatile
        private var INSTANCE: StreamixDatabase? = null

        fun getInstance(context: Context): StreamixDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    StreamixDatabase::class.java,
                    "streamix_bd.db"
                ).fallbackToDestructiveMigration(true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
