package com.example.ui.screens.detail

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.ContentItem
import com.example.data.model.Episode
import com.example.data.repository.StreamixRepository
import com.example.ui.components.ContentPosterCard
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.StreamixFooter
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ContentDetailScreen(
    contentId: String,
    repository: StreamixRepository,
    onBackClick: () -> Unit,
    onWatchClick: (ContentItem, Episode?) -> Unit,
    onRelatedContentClick: (ContentItem) -> Unit,
    onCastClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val contentItem by repository.observeContentById(contentId).collectAsStateWithLifecycle(null)
    val isSaved by repository.isContentSaved(contentId).collectAsStateWithLifecycle(false)
    val episodes by repository.getEpisodesForContent(contentId).collectAsStateWithLifecycle(emptyList())
    val allContent by repository.getAllPublishedContent().collectAsStateWithLifecycle(emptyList())

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var showDownloadDialog by remember { mutableStateOf(false) }
    var selectedEpisodeForDownload by remember { mutableStateOf<Episode?>(null) }
    var selectedQuality by remember { mutableStateOf("1080p Full HD") }

    val relatedContent = remember(contentItem, allContent) {
        if (contentItem == null) emptyList()
        else allContent.filter { it.id != contentItem?.id && (it.genre == contentItem?.genre || it.type == contentItem?.type) }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
    ) {
        if (contentItem == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NeonCyan)
            }
        } else {
            val item = contentItem!!

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("detail_scroll_view")
            ) {
                // Header Backdrop
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp)
                    ) {
                        AsyncImage(
                            model = item.backdropUrl.ifBlank { item.posterUrl },
                            contentDescription = item.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(HeroScrimGradient)
                        )

                        // Top bar navigation
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 36.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onBackClick,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .border(1.dp, GlassCardBorder, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = TextPrimary
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(
                                    onClick = onCastClick,
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.6f))
                                        .border(1.dp, GlassCardBorder, CircleShape)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Cast,
                                        contentDescription = "Cast",
                                        tint = NeonCyan
                                    )
                                }
                            }
                        }
                    }
                }

                // Info Section
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    ) {
                        // Title & Type
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(PurpleCyanGradient)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = item.type,
                                    color = MidnightBlack,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(GlassSurfaceDark)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = AmberRating,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "%.1f".format(item.rating),
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Text(
                                text = "${item.releaseYear} • ${item.durationMinutes} min • ${item.language}",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = item.title,
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = item.genre,
                            color = BrightRedAccent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Primary Watch Button
                            GlassButton(
                                text = "Watch Now",
                                icon = Icons.Default.PlayArrow,
                                onClick = { onWatchClick(item, episodes.firstOrNull()) },
                                modifier = Modifier.weight(1.3f),
                                isPrimary = true,
                                testTag = "detail_watch_btn"
                            )

                            // Download Button
                            GlassButton(
                                text = "Download",
                                icon = Icons.Default.Download,
                                onClick = {
                                    selectedEpisodeForDownload = episodes.firstOrNull()
                                    showDownloadDialog = true
                                },
                                modifier = Modifier.weight(1f),
                                isPrimary = false,
                                testTag = "detail_download_btn"
                            )

                            // Add to My List
                            IconButton(
                                onClick = {
                                    scope.launch {
                                        repository.toggleSaveContent(item.id)
                                        snackbarHostState.showSnackbar(
                                            if (!isSaved) "Added to My List" else "Removed from My List"
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(GlassSurfaceDark)
                                    .border(1.dp, if (isSaved) BrightRedAccent else GlassCardBorder, RoundedCornerShape(12.dp))
                            ) {
                                Icon(
                                    imageVector = if (isSaved) Icons.Default.Check else Icons.Outlined.Add,
                                    contentDescription = "My List",
                                    tint = if (isSaved) BrightRedAccent else TextPrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Synopsis Card
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            backgroundColor = GlassSurfaceDark
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "SYNOPSIS",
                                    color = CrimsonRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = item.description,
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    lineHeight = 19.sp
                                )

                                if (item.castAndCrew.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "CAST & CREW",
                                        color = CrimsonRed,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = item.castAndCrew,
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }

                                if (item.tags.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "FORMAT: ${item.tags}",
                                        color = BrightRedAccent,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }

                // Episodes Section (for Series)
                if (episodes.isNotEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 18.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Episodes (${episodes.size})",
                                    color = TextPrimary,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Season 1",
                                    color = NeonCyan,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            episodes.forEach { ep ->
                                GlassCard(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 5.dp),
                                    onClick = { onWatchClick(item, ep) }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Thumbnail
                                        Box(
                                            modifier = Modifier
                                                .width(110.dp)
                                                .height(68.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(DeepIndigoBg)
                                        ) {
                                            AsyncImage(
                                                model = ep.thumbnailUrl.ifBlank { item.posterUrl },
                                                contentDescription = ep.title,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.Center)
                                                    .size(28.dp)
                                                    .clip(CircleShape)
                                                    .background(Color.Black.copy(alpha = 0.6f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.PlayArrow,
                                                    contentDescription = "Play",
                                                    tint = NeonCyan,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = ep.title,
                                                color = TextPrimary,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "${ep.durationMinutes} min",
                                                color = TextSecondary,
                                                fontSize = 11.sp
                                            )
                                            if (ep.description.isNotBlank()) {
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = ep.description,
                                                    color = TextMuted,
                                                    fontSize = 10.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }

                                        // Download Episode Button
                                        IconButton(
                                            onClick = {
                                                selectedEpisodeForDownload = ep
                                                showDownloadDialog = true
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.Download,
                                                contentDescription = "Download Episode",
                                                tint = NeonCyan,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Related Content
                if (relatedContent.isNotEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp)
                        ) {
                            Text(
                                text = "More Like This",
                                color = TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )

                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(relatedContent, key = { it.id }) { related ->
                                    ContentPosterCard(
                                        content = related,
                                        onClick = { onRelatedContentClick(related) }
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    StreamixFooter()
                    Spacer(modifier = Modifier.height(60.dp))
                }
            }

            // Download Quality Selector Dialog
            if (showDownloadDialog) {
                AlertDialog(
                    onDismissRequest = { showDownloadDialog = false },
                    containerColor = DarkNavyBg,
                    shape = RoundedCornerShape(20.dp),
                    title = {
                        Text(
                            text = "In-App Offline Download",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    text = {
                        Column {
                            Text(
                                text = "Download '${if (selectedEpisodeForDownload != null) selectedEpisodeForDownload!!.title else item.title}' for secure in-app offline viewing.",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            val qualities = listOf(
                                Triple("1080p Full HD", "Recommended for Tablets/TV", "~680 MB"),
                                Triple("720p HD", "Optimal Data & Clarity", "~380 MB"),
                                Triple("480p Standard", "Data Saver Mode", "~190 MB")
                            )

                            qualities.forEach { (q, desc, size) ->
                                val isSelected = selectedQuality == q
                                GlassCard(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    borderColor = if (isSelected) NeonCyan else GlassCardBorder,
                                    backgroundColor = if (isSelected) DeepIndigoBg else GlassSurfaceDark,
                                    onClick = { selectedQuality = q }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(
                                                text = q,
                                                color = if (isSelected) NeonCyan else TextPrimary,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = desc,
                                                color = TextSecondary,
                                                fontSize = 11.sp
                                            )
                                        }
                                        Text(
                                            text = size,
                                            color = VibrantPurple,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        GlassButton(
                            text = "Start Download",
                            icon = Icons.Default.Download,
                            onClick = {
                                showDownloadDialog = false
                                scope.launch {
                                    val res = repository.startDownload(
                                        content = item,
                                        episode = selectedEpisodeForDownload,
                                        quality = selectedQuality
                                    )
                                    if (res.isSuccess) {
                                        snackbarHostState.showSnackbar("Download started in protected vault")
                                    }
                                }
                            }
                        )
                    },
                    dismissButton = {
                        TextButton(onClick = { showDownloadDialog = false }) {
                            Text("Cancel", color = TextSecondary)
                        }
                    }
                )
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}
